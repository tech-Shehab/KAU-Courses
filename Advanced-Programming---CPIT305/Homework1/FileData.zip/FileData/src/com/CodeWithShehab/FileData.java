package com.CodeWithShehab;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
public class FileData {
    private File path;
    private BasicFileAttributes attr;

    public FileData(String path) {
        this.path = new File(path);
        if (!this.path.exists()) {
            try {
                throw new FileNotFoundException("File Not Found!");
            } catch (FileNotFoundException e) {
                System.err.println(e.getMessage());
                // so the program stops
                System.exit(0);
            }
        }
        try {
            attr = Files.readAttributes(Paths.get(this.path.getAbsolutePath()), BasicFileAttributes.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getData() {
        PrintWriter print = null;
        try {
            print = new PrintWriter(new File("output.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (path.isFile()) {
            print.println("> File name is             : " + path.getName());
            print.println("> File type                : File");
            print.println("> Created in               : " + attr.creationTime());
            print.println("> Last accessed in         : " + attr.lastAccessTime());
            print.println("> Last modified in         : " + attr.lastModifiedTime());
            print.println("> Hash using MD5 algorithm : " + MD5Checksum.getMD5Checksum(path.getAbsolutePath()));
            try {
                print.println("> Size                     : " + (Files.size((path.toPath()))) * 0.001 + " KB");
            } catch (IOException e) {
                e.printStackTrace();
            }
            print.println("> is File readable?          " + path.canRead());
            print.println("> is File writable?          " + path.canWrite());
            print.println("> is File executable?        " + path.canWrite());
            print.println("******************************************");

        } else {
            File[] fileArray = path.listFiles();
            for (int i = 0; i < fileArray.length; i++) {
                String fileType = "";
                if (fileArray[i].isDirectory())
                    fileType = "Directory".toUpperCase();
                else
                    fileType = "File".toUpperCase();
                print.println("> File name is             : " + fileArray[i].getName());
                print.println("> File type                : " + fileType);
                print.println("> Created in               : " + attr.creationTime());
                print.println("> Last accessed in         : " + attr.lastAccessTime());
                print.println("> Last modified in         : " + attr.lastModifiedTime());
                try {
                    print.println("> Size                     : " + (Files.size((path.toPath()))) * 0.001 + " KB");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                print.println("> Hash using MD5 algorithm : " + MD5Checksum.getMD5Checksum(fileArray[i].getAbsolutePath()));
                print.println("> is File readable?          " + fileArray[i].canRead());
                print.println("> is File writable?          " + fileArray[i].canWrite());
                print.println("> is File executable?        " + fileArray[i].canWrite());
                print.println("******************************************");
            }
        }
        print.close();
    }
}
