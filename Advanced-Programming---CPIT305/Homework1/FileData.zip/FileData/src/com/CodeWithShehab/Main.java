package com.CodeWithShehab;

public class Main {

    public static void main(String[] args) {
        new FileData("C:\\Users\\Shehab\\Downloads\\OpenHardwareMonitor").getData();

    }
}
