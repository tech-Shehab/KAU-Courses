package edu.kau.fcit.cpit252;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Team {
    private String team;
    private String city;
    private int yearFounded;
    private int championships;

    public Team(String team, String city, int yearFounded, int championships) {
        this.team = team;
        this.city = city;
        this.yearFounded = yearFounded;
        this.championships = championships;
    }

    public static List<Team> retrieveTeams(Connection dbConnection) { // static so it can be accessible from outside the class
        ResultSet rs = null;
        List<Team> teams = new ArrayList<>();
        try {
            Statement stmt = dbConnection.createStatement();
            rs = stmt.executeQuery("SELECT id, team, loc, founded, championships FROM teams");

            while (rs.next()) {
                teams.add(new Team(rs.getString("team"), rs.getString("loc"),
                        rs.getInt("founded"), rs.getInt("championships")));
            }

            return teams;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally { // To make sure that it close
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public String toString() {
        return "Team: " + this.team + "\nLocation: " + this.city
                + "\nFounded in:" + this.yearFounded +
                "\nChampionships: " + this.championships + "\n\n";
    }
}
