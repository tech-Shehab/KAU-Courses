package edu.kau.fcit.cpit252.Adapter;

import java.net.UnknownHostException;

public interface Adapter {
    String getInfo() throws UnknownHostException;
}
