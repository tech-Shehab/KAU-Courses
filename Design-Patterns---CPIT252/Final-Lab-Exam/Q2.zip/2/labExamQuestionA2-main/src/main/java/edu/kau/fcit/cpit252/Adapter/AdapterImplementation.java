package edu.kau.fcit.cpit252.Adapter;

import edu.kau.fcit.cpit252.DNSProvider;

import java.net.UnknownHostException;

public class AdapterImplementation implements Adapter {
    private String str;

    public AdapterImplementation(String str) {
        this.str = str;
    }

    @Override
    public String getInfo() throws UnknownHostException {
        return DNSProvider.hostToIPV4(str);
    }
}