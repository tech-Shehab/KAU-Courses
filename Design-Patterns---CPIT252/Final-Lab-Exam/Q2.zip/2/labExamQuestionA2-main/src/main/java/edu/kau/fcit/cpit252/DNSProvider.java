package edu.kau.fcit.cpit252;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class DNSProvider {

    public static String hostToIPV4(String host) throws UnknownHostException {
        InetAddress inetAddress = java.net.InetAddress.getByName(host);
        return inetAddress.getHostAddress();

        // 0 = 192 , 1 1668
        // 192.162.72.233
//        byte [] arr = {(byte) 192, (byte) 162,72,11};
//        InetAddress a1 = java.net.InetAddress.getByAddress(arr);
//        return a1.getHostName();
    }
}
