package com.CodeWithShehab.Discounts;

import com.CodeWithShehab.Strategy;

public class ClearanceDiscount implements Strategy {
    // %30 ~>
    @Override
    public double getDiscount(double discount) {
        return discount * 0.70;
    }
}
