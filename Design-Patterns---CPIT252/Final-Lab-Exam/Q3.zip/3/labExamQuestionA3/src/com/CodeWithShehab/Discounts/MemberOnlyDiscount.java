package com.CodeWithShehab.Discounts;

import com.CodeWithShehab.Strategy;

public class MemberOnlyDiscount implements Strategy {
    // %20 ~>
    @Override
    public double getDiscount(double discount) {
        return discount * 0.80;
    }
}
