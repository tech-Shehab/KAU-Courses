package com.CodeWithShehab.Discounts;

import com.CodeWithShehab.Strategy;

public class RegularDiscount implements Strategy {
    // %10 ~>
    @Override
    public double getDiscount(double discount) {
        return discount * 0.90;
    }
}
