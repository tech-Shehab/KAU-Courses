package com.CodeWithShehab;

import com.CodeWithShehab.Discounts.ClearanceDiscount;
import com.CodeWithShehab.Discounts.MemberOnlyDiscount;
import com.CodeWithShehab.Discounts.RegularDiscount;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.print("\tEnter The Price of The item > ");
        StrategyUser strategyUser;

        double price = Double.parseDouble(new Scanner(System.in).nextLine());

        strategyUser = new StrategyUser(new RegularDiscount());
        System.out.printf("\t\tRegular Discount     =\t%.2f SAR\n", strategyUser.getUsersDiscount(price));
        strategyUser = new StrategyUser(new MemberOnlyDiscount());
        System.out.printf("\t\tMember Only Discount =\t%.2f SAR\n", strategyUser.getUsersDiscount(price));
        strategyUser = new StrategyUser(new ClearanceDiscount());
        System.out.printf("\t\tClearance Discount   =\t%.2f SAR\n", strategyUser.getUsersDiscount(price));
    }
}
