package com.CodeWithShehab;

public interface Strategy {
    double getDiscount(double discount);
}
