package com.CodeWithShehab;

public class StrategyUser {
    private Strategy strategy;

    public StrategyUser(Strategy strategy) {
        this.strategy = strategy;
    }
    public double getUsersDiscount(double discount){
        return strategy.getDiscount(discount);
    }
}
