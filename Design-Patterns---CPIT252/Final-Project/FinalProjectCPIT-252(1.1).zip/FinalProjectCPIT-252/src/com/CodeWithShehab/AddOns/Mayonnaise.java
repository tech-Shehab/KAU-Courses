package com.CodeWithShehab.AddOns;

import com.CodeWithShehab.AddOnsDecorator;
import com.CodeWithShehab.BaseBurger;

public class Mayonnaise extends AddOnsDecorator {

    public Mayonnaise(BaseBurger burger) {
        super.burger = burger;
    }

    @Override
    public String getBurgerType() {
        return burger.getBurgerType();
    }

    @Override
    public String getAddOns() {
        return burger.getAddOns() + " ,Mayonnaise";
    }
}
