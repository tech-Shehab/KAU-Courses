package com.CodeWithShehab.AddOns;

import com.CodeWithShehab.AddOnsDecorator;
import com.CodeWithShehab.BaseBurger;

public class RoyalSauce extends AddOnsDecorator {

    public RoyalSauce(BaseBurger burger) {
        this.burger = burger;
    }

    @Override
    public String getBurgerType() {
        return burger.getBurgerType();
    }

    @Override
    public String getAddOns() {
        return burger.getAddOns() + " ,Royal sauce";
    }
}
