package com.CodeWithShehab;

public abstract class AddOnsDecorator extends BaseBurger{
    protected BaseBurger burger;

    public abstract String getBurgerType();
}
