package com.CodeWithShehab;

public abstract class BaseBurger {
    protected String burgerType = "Unknown burger";

    public String getBurgerType() {
        return burgerType;
    }

    public abstract String getAddOns();
}
