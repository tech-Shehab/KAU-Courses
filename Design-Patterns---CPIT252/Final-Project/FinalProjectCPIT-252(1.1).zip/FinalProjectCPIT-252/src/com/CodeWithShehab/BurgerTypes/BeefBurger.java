package com.CodeWithShehab.BurgerTypes;

import com.CodeWithShehab.BaseBurger;

public class BeefBurger extends BaseBurger {
    public BeefBurger() {
        super.burgerType = "Beef burger";
    }

    @Override
    public String getAddOns() {
        return "";
    }
}
