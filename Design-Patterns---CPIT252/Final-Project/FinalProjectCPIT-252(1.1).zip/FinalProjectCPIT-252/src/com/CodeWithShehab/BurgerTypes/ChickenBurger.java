package com.CodeWithShehab.BurgerTypes;

import com.CodeWithShehab.BaseBurger;

public class ChickenBurger extends BaseBurger {
    public ChickenBurger() {
        super.burgerType = "Chicken burger";
    }

    @Override
    public String getAddOns() {
        return "";
    }
}
