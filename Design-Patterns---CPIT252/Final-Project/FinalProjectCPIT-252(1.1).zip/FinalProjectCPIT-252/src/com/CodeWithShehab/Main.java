package com.CodeWithShehab;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        displayMenu();
    }

    public static void displayMenu(){
        System.out.println("*** Welcome to Royal Restaurant ***\n");
        System.out.println("  * Royal Restaurant offers 2 types of burgers:");
        System.out.println("\tBeef - Chicken");
        System.out.println("  * With the following addons:");
        System.out.println("\tCheese - Cocktail - Ketchup \n\tMayonnaise - RoyalSauce - Vegetables");
        System.out.println("  * Please make sure you type the " +
                "order separated by space, burger type first then the addons");
        System.out.println("\texample> Beef cheese pickles vegetables");
        while (true) {
            System.out.println("\n\t*Type 0 to exit*");
            System.out.print("\t\t> Type your order: ");
            String choice = new Scanner(System.in).nextLine();
            if (choice.equals("0")) {
                break;
            }
            Order.makeOrder(choice);
        }
        System.out.println("Thanks for using the system!");
    }
}
