package com.CodeWithShehab;

import com.CodeWithShehab.AddOns.*;
import com.CodeWithShehab.BurgerTypes.*;

public class Order {

    private Order() {
    }

    public static void makeOrder(String str) {
        Logger logger = Logger.getInstance();
        BaseBurger burger = null;

        String[] list = str.split(" ");

        for (int i = 0; i < list.length; i++) {
            switch (list[i].toLowerCase()) {
                case "cheese":
                    burger = new Cheese(burger);
                    break;
                case "chicken":
                    burger = new ChickenBurger();
                    break;
                case "beef":
                    burger = new BeefBurger();
                    break;
                case "cocktail":
                    burger = new Cocktail(burger);
                    break;
                case "ketchup":
                    burger = new Ketchup(burger);
                    break;
                case "mayonnaise":
                    burger = new Mayonnaise(burger);
                    break;
                case "royalsauce":
                    burger = new RoyalSauce(burger);
                    break;
                case "vegetables":
                    burger = new Vegetables(burger);
                    break;
            }
        }

        System.out.println("\n\tBurger type is: " + burger.getBurgerType() + ". \n\tAddons are    : " + burger.getAddOns());
        logger.write("\n\tBurger type is: " + burger.getBurgerType() + ". \n\tAddons are    :" + burger.getAddOns());
    }
}
