package com.CodeWithShehab;

public class Burger {
    private Cheese cheese;
    private Pickles pickles;
    private Vegetables vegetables;

    public void setCheese(Cheese cheese) {
        this.cheese = cheese;
    }

    public void setPickles(Pickles pickles) {
        this.pickles = pickles;
    }

    public void setVegetables(Vegetables vegetables) {
        this.vegetables = vegetables;
    }

}
