package com.CodeWithShehab;

public class BurgerBuilder {

    private BurgerInterface burgerInterface;

    public BurgerBuilder(BurgerInterface burger) {
        if (burger == null)
            throw new IllegalArgumentException("Meat can not be null");
        else if (burger instanceof Beef) {
            burgerInterface = new Beef();
        } else{
            burgerInterface = new Chicken();
        }
    }

    public BurgerBuilder withCheese(Cheese cheese) {
        burgerInterface.withCheese(cheese);
        return this;
    }

    public BurgerBuilder withPickles(Pickles pickles) {
        burgerInterface.withPickles(pickles);
        return this;
    }

    public BurgerBuilder withVegetables(Vegetables vegetables) {
        burgerInterface.withVegetables(vegetables);
        return this;
    }

    public BurgerBuilder build() {
        return this;
    }
}
