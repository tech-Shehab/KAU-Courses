package com.CodeWithShehab;

public class BurgerFactory {
    private static Logger logger = Logger.getLogger();
    private static BurgerBuilder builder;
    public static void createStandardBurger(Meat meat,boolean loggerStatus) {

        switch (meat) {
            case BEEF:
                builder = new BurgerBuilder(new Beef()).withCheese(Cheese.CHEDDAR)
                        .withPickles(Pickles.PICKLES).withVegetables(Vegetables.VEGETABLES).build();
                logger.addToLogger("\t*\tBurger is " + Meat.BEEF + "\n\t*\tCheese is " + Cheese.CHEDDAR + "\n\t*\tWith " + Pickles.PICKLES + "\n\t*\tWith " + Vegetables.VEGETABLES);
                break;
            case CHICKEN:
                builder = new BurgerBuilder(new Chicken()).withCheese(Cheese.WHITE)
                        .withPickles(Pickles.NO_PICKLES).withVegetables(Vegetables.VEGETABLES).build();
                logger.addToLogger("\t*\tBurger is " + Meat.CHICKEN + "\n\t*\tCheese is " + Cheese.WHITE + "\n\t*\tWith " + Pickles.NO_PICKLES + "\n\t*\tWith " + Vegetables.VEGETABLES);

        }
        if(!loggerStatus)
            Logger.close();
    }
    public static void createCustomizedBurger(Meat meat, Cheese cheese, Pickles pickles, Vegetables vegetables, boolean loggerStatus){
        if (meat.equals(Meat.BEEF)) {
            builder = new BurgerBuilder(new Beef()).withCheese(cheese)
                    .withPickles(pickles).withVegetables(vegetables).build();
            logger.addToLogger("\t*\tBurger is " + Meat.BEEF + "\n\t*\tCheese is " + cheese
                    + "\n\t*\tWith " + pickles + "\n\t*\tWith " + vegetables);
        }
        else {
            builder = new BurgerBuilder(new Chicken()).withPickles(pickles).withVegetables(vegetables).build();
            logger.addToLogger("\t*\tBurger is " + Meat.BEEF + "\n\t*\tCheese is " + cheese
                    + "\n\t*\tWith " + pickles + "\n\t*\tWith " + vegetables);
        }
        if (!loggerStatus)
            Logger.close();
    }

}
