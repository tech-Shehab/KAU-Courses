package com.CodeWithShehab;

public interface BurgerInterface {
    public Burger withPickles(Pickles pickles);
    public Burger withCheese(Cheese cheese);
    public Burger withVegetables(Vegetables vegetables);
    public Burger getBurger();
}
