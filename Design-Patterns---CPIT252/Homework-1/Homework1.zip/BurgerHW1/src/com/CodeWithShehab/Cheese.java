package com.CodeWithShehab;

public enum Cheese {
    CHEDDAR,
    WHITE;

    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
