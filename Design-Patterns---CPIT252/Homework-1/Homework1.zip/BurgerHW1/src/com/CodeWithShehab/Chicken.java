package com.CodeWithShehab;

public class Chicken implements BurgerInterface {
    private Burger burger;

    public Chicken() {
        burger = new Burger();
    }

    @Override
    public Burger withPickles(Pickles pickles) {
        burger.setPickles(pickles);
        return burger;
    }

    @Override
    public Burger withCheese(Cheese cheese) {
        burger.setCheese(cheese);
        return burger;
    }

    @Override
    public Burger withVegetables(Vegetables vegetables) {
        burger.setVegetables(vegetables);
        return burger;
    }

    @Override
    public Burger getBurger() {
        return burger;
    }
}
