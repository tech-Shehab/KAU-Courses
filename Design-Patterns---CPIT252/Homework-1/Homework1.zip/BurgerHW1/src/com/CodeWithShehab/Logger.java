package com.CodeWithShehab;

import java.io.*;

public class Logger {
    private static Logger logger = null;
    private static FileWriter writer;
    int counter = 100;

    private Logger() {
        try {
            writer = new FileWriter("logger.txt",true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.write("**********************************\n"+
                    new java.util.Date() + "\n" +
                    "**********************************\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Logger getLogger() {
        if (logger == null)
            return logger = new Logger();
        else
            return logger;
    }

    public static void close(){
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addToLogger(String str) {
        try {
            writer.write(" > order number (" + ++counter + "): \n" + str + "\n\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
