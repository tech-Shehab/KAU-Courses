package com.CodeWithShehab;

public class Main {

    public static void main(String[] args) {
        BurgerFactory.createStandardBurger(Meat.BEEF,true);

        BurgerFactory.createCustomizedBurger(Meat.BEEF,Cheese.CHEDDAR
                ,Pickles.PICKLES,Vegetables.VEGETABLES,false);
    }
}

