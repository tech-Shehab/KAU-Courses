package com.CodeWithShehab;

public enum Meat {
    CHICKEN,
    BEEF;

    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
