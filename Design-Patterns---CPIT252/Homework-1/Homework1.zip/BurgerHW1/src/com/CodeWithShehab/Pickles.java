package com.CodeWithShehab;

public enum Pickles {
    PICKLES,
    NO_PICKLES;

    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
