package com.CodeWithShehab;

public enum Vegetables {
    VEGETABLES,
    NO_VEGETABLES;

    @Override
    public String toString() {
        return name().toLowerCase();
    }
}
