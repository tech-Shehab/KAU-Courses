package com.CodeWithShehab;

public abstract class Chemistry {
    public abstract String getName();
    public abstract void print();
    public abstract void add(Chemistry chemistry);
    public abstract void remove(Chemistry chemistry);
}
