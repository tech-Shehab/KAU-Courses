package com.CodeWithShehab;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Compound extends Chemistry{

    private String compound;
    private List<Chemistry> list = new ArrayList<>();
    private static ArrayList<Compound> compounds = new ArrayList<>();

    private Compound(String compound) {
        this.compound = compound;
        compounds.add(this);
    }

    public static Compound getCompound(String compound){
        for (int i = 0; i < compounds.size(); i++) {
            if(compounds.get(i).getName().equals(compound))
                return compounds.get(i);
        }
        return new Compound(compound);
    }

    @Override
    public String getName() {
        return compound;
    }

    public static ArrayList<Compound> getCompounds() {
        return compounds;
    }

    @Override
    public void print() {
        System.out.println("Compound: " + compound);
        Iterator<Chemistry> iterator = list.iterator();
        System.out.println("\tContains of >");
        while (iterator.hasNext()) {
            Chemistry chemistry = iterator.next();
            System.out.print("\t\t");
            chemistry.print();
        }
    }

    @Override
    public void add(Chemistry chemistry) {
        list.add(chemistry);
    }

    @Override
    public void remove(Chemistry chemistry) {
        list.remove(chemistry);
    }
}
