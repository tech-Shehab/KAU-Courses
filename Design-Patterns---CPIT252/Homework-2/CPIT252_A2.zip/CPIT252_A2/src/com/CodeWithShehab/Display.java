package com.CodeWithShehab;

import java.util.ArrayList;
import java.util.Scanner;

public class Display {

    private Display(){}

    public static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        String choice;
        boolean bool = false;
        System.out.println("****************************");
        System.out.println("* Welcome to Chemistry Lab *");
        System.out.println("****************************");
        while (!bool) {
            System.out.println("1> Add Element");
            System.out.println("2> Add Compound");
            System.out.println("3> View all Elements");
            System.out.println("4> View all Compounds");
            System.out.println("5> Remove Element");
            System.out.println("6> Remove Compound");
            System.out.println("!> any other number to exit");
            System.out.print("\t > Enter a choice$ ");
            choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    System.out.print("Enter the name of the element: ");
                    Element.getElement(scanner.nextLine());
                    break;
                case "2":
                    System.out.print("Enter the name of the compound: ");
                    Compound compound = Compound.getCompound(scanner.nextLine());
                    System.out.println("How many elements in the compound?");
                    int y = Integer.parseInt(scanner.nextLine());
                    for (int i = 0; i < y; i++) {
                        System.out.println("Element number #"+ (i+1) + " : ");
                        compound.add(Element.getElement(scanner.nextLine()));
                    }
                    System.out.println("How many compounds in the compound?");
                    int z = Integer.parseInt(scanner.nextLine());
                    for (int i = 0; i < z; i++) {
                        System.out.println("Compound number #"+ (i+1) + " : ");
                        compound.add(Compound.getCompound(scanner.nextLine()));
                    }
                    break;
                case "3":
                    System.out.println();
                    ArrayList<Element> elements = Element.getElements();
                    if (elements.size() == 0) {
                        System.err.println("No elements in the System!");
                        break;
                    }
                    for (int i = 0; i < elements.size(); i++) {
                        System.out.print("#" + (i+1) +" ");
                        elements.get(i).print();
                    }
                    System.out.println();
                    break;
                case "4":
                    System.out.println();
                    ArrayList<Compound> compounds = Compound.getCompounds();
                    if (compounds.size() == 0) {
                        System.err.println("No compounds in the System!");
                        break;
                    }
                    for (int i = 0; i < compounds.size(); i++) {
                        System.out.print("#" + (i+1) +" ");
                        compounds.get(i).print();
                    }
                    System.out.println();
                    break;
                case "5":
                    if (Element.getElements().size() == 0) {
                        System.err.println("there is no elements in the system!");
                        break;
                    }
                    System.out.println("Enter the name of the element you want to remove");
                    String name = scanner.nextLine();
                    Element element = null;
                    for (int i = 0; i < Element.getElements().size(); i++) {
                        if(Element.getElements().get(i).getName().equals(name)) {
                            element = Element.getElements().get(i);
                            Element.getElements().remove(i);
                            System.out.println("Element has been removed!");
                            break;
                        }
                    }
                    if(element == null)
                        System.err.println("element doesn't exists!");
                    break;
                case "6":
                    if (Compound.getCompounds().size() == 0) {
                        System.err.println("there is no compounds in the system!");
                        break;
                    }
                    System.out.println("Enter the name of the compound you want to remove");
                    String nam = scanner.nextLine();
                    Compound compound1 = null;
                    for (int i = 0; i < Compound.getCompounds().size(); i++) {
                        if(Compound.getCompounds().get(i).getName().equals(nam)) {
                            compound1 = Compound.getCompounds().get(i);
                            Compound.getCompounds().remove(i);
                            System.out.println("compound has been removed!");
                            break;
                        }
                    }
                    if(compound1 == null)
                        System.err.println("compound doesn't exists!");
                    break;
                default:
                    bool = true;
                    break;
            }
        }
        System.out.println("Thanks for using our system!");
    }
}
