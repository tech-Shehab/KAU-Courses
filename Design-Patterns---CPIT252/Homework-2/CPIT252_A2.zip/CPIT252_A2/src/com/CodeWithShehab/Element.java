package com.CodeWithShehab;

import java.util.ArrayList;

public class Element extends Chemistry{

    private String element;
    private static ArrayList<Element> elements = new ArrayList<>();

    private Element(String element) {
        this.element = element;
        elements.add(this);
    }

    public static Element getElement(String name) {
        for (int i = 0; i < elements.size(); i++) {
            if(elements.get(i).getName().equals(name))
                return elements.get(i);
        }
        return new Element(name);
    }

    public static ArrayList<Element> getElements() {
        return elements;
    }

    @Override
    public String getName() {
        return element;
    }

    @Override
    public void print() {
        System.out.println("Element = " + element);
    }

    @Override
    public void add(Chemistry chemistry) {}

    @Override
    public void remove(Chemistry chemistry) {}
}
