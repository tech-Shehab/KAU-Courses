package com.CodeWithShehab;

public class Main {
    public static void main(String[] args) {
        /**
         * Elements examples >
         * Na
         * H
         * O
         * CL
         * Compounds examples >
         * H2o >>> HHO
         * NaCL
         * */
        Display.displayMenu();
    }
}
