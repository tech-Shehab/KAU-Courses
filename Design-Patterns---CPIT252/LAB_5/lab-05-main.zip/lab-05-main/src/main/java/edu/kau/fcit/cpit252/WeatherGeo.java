package edu.kau.fcit.cpit252;

public interface WeatherGeo {
    public String getWeatherInfo(double latitude, double longitude);
}
