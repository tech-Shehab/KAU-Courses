package com.CodeWithShehab;

public abstract class BaseLogger {
    protected String label = "Unknown label";

    public String getLabel() {
        return label;
    }

    public abstract String getLevel();
}
