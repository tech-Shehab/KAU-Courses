package com.CodeWithShehab;

public abstract class FormatDecorator extends BaseLogger {
     protected BaseLogger logger;
    // All format decorators have to reimplement the getLabel method
    public abstract String getLabel();
}

