package com.CodeWithShehab.Formatters;

import com.CodeWithShehab.BaseLogger;
import com.CodeWithShehab.FormatDecorator;

public class CSVFormatter extends FormatDecorator {
    public CSVFormatter(BaseLogger logger) {
        this.logger = logger;
    }

    @Override
    public String getLevel() {
        return "Info " + logger.getLevel();
    }

    @Override
    public String getLabel() {
        return logger.getLabel() + ", CSVFormatter";
    }
}
