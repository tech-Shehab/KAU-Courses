package com.CodeWithShehab.Formatters;

import com.CodeWithShehab.BaseLogger;
import com.CodeWithShehab.FormatDecorator;

public class HTMLFormatter extends FormatDecorator {
    public HTMLFormatter(BaseLogger logger) {
        this.logger = logger;
    }

    @Override
    public String getLevel() {
        return "Info " + logger.getLevel();
    }

    @Override
    public String getLabel() {
        return logger.getLabel() + ", HTMLFormatter";
    }
}
