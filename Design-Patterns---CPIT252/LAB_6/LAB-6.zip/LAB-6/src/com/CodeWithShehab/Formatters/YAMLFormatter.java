package com.CodeWithShehab.Formatters;

import com.CodeWithShehab.BaseLogger;
import com.CodeWithShehab.FormatDecorator;

public class YAMLFormatter extends FormatDecorator {
    public YAMLFormatter(BaseLogger logger) {
        this.logger = logger;
    }

    @Override
    public String getLevel() {
        return "info " + logger.getLevel();
    }

    @Override
    public String getLabel() {
        return logger.getLabel() + ", YAMALFormatter";
    }
}
