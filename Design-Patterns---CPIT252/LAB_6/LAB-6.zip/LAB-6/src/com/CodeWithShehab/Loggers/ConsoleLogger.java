package com.CodeWithShehab.Loggers;

import com.CodeWithShehab.BaseLogger;

public class ConsoleLogger extends BaseLogger {
    public ConsoleLogger() {
        label = "Console logger";
    }

    @Override
    public String getLevel() {
        return "info";
    }
}

