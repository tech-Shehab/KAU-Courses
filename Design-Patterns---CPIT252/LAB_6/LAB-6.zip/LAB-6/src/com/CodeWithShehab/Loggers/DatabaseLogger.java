package com.CodeWithShehab.Loggers;

import com.CodeWithShehab.BaseLogger;

public class DatabaseLogger extends BaseLogger {
    public DatabaseLogger() {
        label = "database logger";
    }

    @Override
    public String getLevel(){
        return "error";
    }
}
