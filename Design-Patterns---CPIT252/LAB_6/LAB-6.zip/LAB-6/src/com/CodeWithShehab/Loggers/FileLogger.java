package com.CodeWithShehab.Loggers;

import com.CodeWithShehab.BaseLogger;

public class FileLogger extends BaseLogger {
    public FileLogger() {
        label = "File logger";
    }

    @Override
    public String getLevel() {
        return "debug";
    }
}
