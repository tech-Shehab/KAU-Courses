package com.CodeWithShehab;

import java.util.ArrayList;

public class MessageSubject implements Subject{

    private ArrayList<Observer> list = new ArrayList<>();

    @Override
    public void subscribe(Observer o) {
        list.add(o);
    }

    @Override
    public void unsubscribe(Observer o) {
        list.remove(o);
    }

    @Override
    public void notifyUpdate(String m) {
        for (int i = 0; i < list.size(); i++) {
            list.get(i).update(m);
        }
    }
}
