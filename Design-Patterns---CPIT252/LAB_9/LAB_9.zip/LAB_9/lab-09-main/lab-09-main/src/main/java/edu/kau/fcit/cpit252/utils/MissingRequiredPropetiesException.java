package edu.kau.fcit.cpit252.utils;

public class MissingRequiredPropetiesException extends Exception{
    public MissingRequiredPropetiesException(String message){
        super(message);
    }
}
