package edu.kau.fcit.cpit252.paymentsStrategy;

public interface Payment {
    void pay(double amount);
}
